import javax.swing.*;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import javax.swing.table.DefaultTableModel;


public class Tester {

    private static final String USERNAME = "a";
    private static final String PASSWORD = "aa";
    // Add this at the beginning of the Tryer class
    private static DefaultTableModel tableModel = new DefaultTableModel(new Object[]{"Student Name", "Student No.", "Final Semestral Grade"}, 0);
   
    public static void main(String[] args) {
        JFrame frame = new JFrame("University Grade Encoding System");
        JFrame.setDefaultLookAndFeelDecorated(true);
        frame.setSize(1050, 630);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.getContentPane().setBackground(Color.decode("#41489f"));

        JPanel titleBar = new JPanel();
        titleBar.setBackground(Color.BLACK);
        titleBar.setBounds(0, 0, 1050, 20);
        titleBar.setLayout(null);

        JLabel titleLabel = new JLabel("");
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setBounds(20, 10, 400, 30);
        titleBar.add(titleLabel);
        frame.add(titleBar);

        JPanel panel = new JPanel();
        panel.setBackground(Color.decode("#101238"));
        panel.setBounds(30, 100, 400, 450);
        panel.setLayout(null);

        JLabel messageLabel = new JLabel("Login to system");
        messageLabel.setForeground(Color.WHITE);
        messageLabel.setFont(new Font("Arial", Font.BOLD, 26));
        messageLabel.setBounds(50, 50, 250, 30);
        panel.add(messageLabel);

        JLabel additionalMessageLabel = new JLabel("Please enter your username and password below");
        additionalMessageLabel.setForeground(Color.WHITE);
        additionalMessageLabel.setFont(new Font("Arial", Font.PLAIN, 13));
        additionalMessageLabel.setBounds(50, 90, 350, 30);
        panel.add(additionalMessageLabel);

        JTextField usernameField = new JTextField("Username");
        usernameField.setBounds(50, 180, 300, 20);
        usernameField.setForeground(Color.GRAY);
        usernameField.setBorder(BorderFactory.createEmptyBorder());
        usernameField.setBackground(Color.decode("#101238"));
        usernameField.setCaretColor(Color.WHITE);
        panel.add(usernameField);

        JPanel usernameLine = new JPanel();
        usernameLine.setBackground(Color.WHITE);
        usernameLine.setBounds(50, 200, 300, 1);
        panel.add(usernameLine);

        usernameField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (usernameField.getText().equals("Username")) {
                    usernameField.setText("");
                    usernameField.setForeground(Color.WHITE);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (usernameField.getText().isEmpty()) {
                    usernameField.setText("Username");
                    usernameField.setForeground(Color.GRAY);
                }
            }
        });

        JPasswordField passwordField = new JPasswordField("Password");
        passwordField.setBounds(50, 230, 300, 20);
        passwordField.setForeground(Color.GRAY);
        passwordField.setBorder(BorderFactory.createEmptyBorder());
        passwordField.setBackground(Color.decode("#101238"));
        passwordField.setCaretColor(Color.WHITE);
        panel.add(passwordField);

        JPanel passwordLine = new JPanel();
        passwordLine.setBackground(Color.WHITE);
        passwordLine.setBounds(50, 250, 300, 1);
        panel.add(passwordLine);

        passwordField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (new String(passwordField.getPassword()).equals("Password")) {
                    passwordField.setEchoChar((char) 0);
                    passwordField.setText("");
                    passwordField.setForeground(Color.WHITE);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (new String(passwordField.getPassword()).isEmpty()) {
                    passwordField.setEchoChar('\u2022');
                    passwordField.setText("Password");
                    passwordField.setForeground(Color.GRAY);
                }
            }
        });

        JCheckBox showPasswordCheckBox = new JCheckBox("Show Password");
        showPasswordCheckBox.setBounds(50, 270, 150, 20);
        showPasswordCheckBox.setBackground(Color.decode("#101238"));
        showPasswordCheckBox.setForeground(Color.WHITE);
        panel.add(showPasswordCheckBox);

        showPasswordCheckBox.addActionListener(e -> {
            if (showPasswordCheckBox.isSelected()) {
                passwordField.setEchoChar((char) 0);
            } else {
                passwordField.setEchoChar('\u2022');
            }
        });

        JButton loginButton = new JButton("Login");
        loginButton.setBounds(140, 350, 100, 20);
        panel.add(loginButton);

        loginButton.addActionListener(e -> {
            String enteredUsername = usernameField.getText();
            String enteredPassword = new String(passwordField.getPassword());
            if (enteredUsername.equals(USERNAME) && enteredPassword.equals(PASSWORD)) {
                frame.dispose();
                showNewWindow();
            } else {
                JOptionPane.showMessageDialog(frame, "Login Failed. Please check your username and password.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        JPanel panel2 = new JPanel() {
            /**
			 * 
			 */
			private static final long serialVersionUID = 1L;
			private BufferedImage backgroundImage;

            {
                try {
                    backgroundImage = ImageIO.read(new File("C:\\Users\\JAYGAB\\Desktop\\backgroundloginn.jpg"));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), null);
                }
            }
        };
        panel2.setBounds(430, 100, 550, 450);
        panel2.setLayout(null);
        frame.add(panel);
        frame.add(panel2);
        frame.setVisible(true);
    }

    private static void showNewWindow() {
        JFrame newFrame = new JFrame("University Grade Encoding System");
        newFrame.setSize(1200, 630);
        newFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        newFrame.setLayout(null);
        newFrame.getContentPane().setBackground(Color.decode("#41489f"));

        JPanel newTitleBar = new JPanel();
        newTitleBar.setBackground(Color.BLACK);
        newTitleBar.setBounds(0, 0, 1050, 20);
        newTitleBar.setLayout(null);
        
        JLabel newTitleLabel = new JLabel("");
        newTitleLabel.setForeground(Color.WHITE);
        newTitleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        newTitleLabel.setBounds(20, 10, 400, 30);
        newTitleBar.add(newTitleLabel);
        newFrame.add(newTitleBar);

        JPanel newPanel = new JPanel();
        newPanel.setBackground(Color.decode("#101238"));
        newPanel.setBounds(0, 0, 1200, 100);
        newPanel.setLayout(null);

        JLabel welcomeLabel = new JLabel("Welcome to our University Grade Encoding System");
        welcomeLabel.setForeground(Color.WHITE);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 26));
        welcomeLabel.setBounds(300, 0, 1050, 100);
        newPanel.add(welcomeLabel);

        newFrame.add(newPanel);
        
        JPanel newPanel2 = new JPanel();
        newPanel2.setBackground(Color.decode("#101238"));
        newPanel2.setBounds(0, 0, 150, 650);
        newPanel2.setLayout(null);

        JButton encodeGradeButton = new JButton("Encode Grade");
        encodeGradeButton.setBounds(10, 150, 130, 30);
        newPanel2.add(encodeGradeButton);

        JButton gradingSystemButton = new JButton("Grading System");
        gradingSystemButton.setBounds(10, 250, 130, 30);
        newPanel2.add(gradingSystemButton);

        JButton aboutUsButton = new JButton("About Us");
        aboutUsButton.setBounds(10, 350, 130, 30);
        newPanel2.add(aboutUsButton);

        JButton logoutButton = new JButton("Logout");
        logoutButton.setBounds(10, 450, 130, 30);
        newPanel2.add(logoutButton);

        logoutButton.addActionListener(e -> {
            newFrame.dispose();
            showLoginWindow();
        });

        // Add action listener for the "About Us" button
        aboutUsButton.addActionListener(e -> showAboutUsWindow());

        // Add action listener for the "Grading System" button
        gradingSystemButton.addActionListener(e -> showGradingSystemWindow());

        newFrame.add(newPanel2);
        newFrame.setVisible(true);

        newFrame.add(newPanel2);
        newFrame.setVisible(true);
    
        JPanel newPanel3 = new JPanel();
        newPanel3.setBackground(Color.decode("#101238"));
        newPanel3.setBounds(160, 110, 450, 150);
        newPanel3.setLayout(null);
     
        // Create the label for "Student Information"
        JLabel studentInfoLabel = new JLabel("Student Information");
        studentInfoLabel.setForeground(Color.WHITE); // Set text color to white
        studentInfoLabel.setFont(new Font("Arial", Font.BOLD, 16)); // Set font to bold
        studentInfoLabel.setBounds(20, 10, 200, 30); // Set position and size within the panel

        // Add the label to newPanel3
        newPanel3.add(studentInfoLabel);
        
        // Create a label and text field for "Student Name"
        JLabel studentNameLabel = new JLabel("Student Name:");
        studentNameLabel.setForeground(Color.WHITE);
        studentNameLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        studentNameLabel.setBounds(20, 60, 100, 20);
        newPanel3.add(studentNameLabel);

        JTextField studentNameField = new JTextField();
        studentNameField.setBounds(150, 60, 250, 20);
        studentNameField.setForeground(Color.BLACK);
        studentNameField.setBorder(BorderFactory.createEmptyBorder());
        newPanel3.add(studentNameField);

        // Create a label and text field for "Student Number"
        JLabel studentNumberLabel = new JLabel("Student Number:");
        studentNumberLabel.setForeground(Color.WHITE);
        studentNumberLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        studentNumberLabel.setBounds(20, 100, 120, 20);
        newPanel3.add(studentNumberLabel);

        JTextField studentNumberField = new JTextField();
        studentNumberField.setBounds(150, 100, 250, 20);
        studentNumberField.setForeground(Color.BLACK);
        studentNumberField.setBorder(BorderFactory.createEmptyBorder());
        newPanel3.add(studentNumberField);

        // Add the panel to the new frame
        newFrame.add(newPanel3);   
        
        JPanel newPanel4 = new JPanel();
        newPanel4.setBackground(Color.decode("#101238"));
        newPanel4.setBounds(160, 272, 450, 320);
        newPanel4.setLayout(null); // Set layout to null for manual positioning

        // Create the label for "Student Final Semestral Grade"
        JLabel finalGradeLabel = new JLabel("Student Final Semestral Grade");
        finalGradeLabel.setForeground(Color.WHITE); // Set text color to white
        finalGradeLabel.setFont(new Font("Arial", Font.BOLD, 16)); // Set font to bold
        finalGradeLabel.setBounds(20, 10, 300, 30); // Set position and size within the panel
        newPanel4.add(finalGradeLabel);

     // Course labels and fields
        String[] courses = {"SOC101", "ENT101", "STS101", "ETH101", "PED103", "RIZ101", "CPP106", "CPA101", "COE108"};
        JTextField[] gradeFields = new JTextField[courses.length];

        for (int i = 0; i < courses.length; i++) {
            JLabel courseLabel = new JLabel(courses[i] + ":");
            courseLabel.setForeground(Color.WHITE); // Set text color to white
            courseLabel.setFont(new Font("Arial", Font.PLAIN, 12)); // Set font to plain
            courseLabel.setBounds(20, 50 + (i * 30), 100, 20); // Position the label

            newPanel4.add(courseLabel);

            gradeFields[i] = new JTextField();
            gradeFields[i].setBounds(120, 50 + (i * 30), 100, 20); // Position the text field
            newPanel4.add(gradeFields[i]); // Add the text field for each course
        }

        // Add the panel to the new frame
        newFrame.add(newPanel4);
        
        JPanel newPanel5 = new JPanel();
        newPanel5.setBackground(Color.decode("#101238"));
        newPanel5.setBounds(620, 110, 560, 470);
        newPanel5.setLayout(null);

        // Create the table with the data and column names
        JTable table = new JTable(tableModel);

        // Set up the table model to make it scrollable
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(10, 10, 540, 450); // Set position and size for the scroll pane

        // Add the scroll pane to newPanel5
        newPanel5.add(scrollPane);

        // Add the panel to the new frame
        newFrame.add(newPanel5);
        
     // Action listener for the Encode Grade button
        encodeGradeButton.addActionListener(e -> {
            String studentName = studentNameField.getText();
            String studentNumber = studentNumberField.getText();

            // Collect grades
            double total = 0;
            int count = 0;
            for (JTextField gradeField : gradeFields) {
                String text = gradeField.getText();
                if (!text.isEmpty()) {
                    try {
                        double grade = Double.parseDouble(text);
                        total += grade;
                        count++;
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(newFrame, "Invalid grade entered for one of the courses.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }
            }

            // Calculate final semestral grade
            double finalGrade = count > 0 ? total / count : 0;

            // Add data to the table
            if (!studentName.isEmpty() && !studentNumber.isEmpty()) {
                tableModel.addRow(new Object[]{studentName, studentNumber, finalGrade});
            } else {
                JOptionPane.showMessageDialog(newFrame, "Please enter both Student Name and Student Number.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private static void showGradingSystemWindow() {
        JFrame gradingFrame = new JFrame("Grading System");
        gradingFrame.setSize(700, 400);
        gradingFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        gradingFrame.setLayout(new BorderLayout());

        // Set the background color for the gradingFrame
        gradingFrame.getContentPane().setBackground(Color.decode("#101238"));

        // Title label
        JLabel titleLabel = new JLabel("<html><h2 style='color: white;'>Grading System</h2></html>", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        gradingFrame.add(titleLabel, BorderLayout.NORTH);

        // Text area to display grading information
        JTextArea gradingInfoTextArea = new JTextArea();
        gradingInfoTextArea.setText("Grading System:\n"
                + "----------------------------------\n"
        		+ "Grade Range				Equivalent		Remarks\n"
                + " 100 - 96 		   	   	   1.00 	   	Passed\n"
                + "  95-92			  	   1.25  		Passed\n"
                + "  91-88 				   1.50 		Passed\n"
                + "  87-84 				   1.75 		Passed\n"
                + "  83-80 				   2.00		Passed\n"
                + "  79-75 				   2.25 		Passed\n"
                + "  74-70 				   2.50 		Passed\n"
                + "  69-65 				   2.75 		Passed\n"
                + "  64-60 				   3.00 		Passed\n"
                + "  59-0 				   5.00 		Passed\n"
                + "----------------------------------\n");
        
        gradingInfoTextArea.setFont(new Font("Arial", Font.PLAIN, 14));
        gradingInfoTextArea.setEditable(false);
        gradingInfoTextArea.setBackground(Color.decode("#101238"));
        gradingInfoTextArea.setForeground(Color.WHITE); // Set the font color to white

        // Adding the text area to the frame
        gradingFrame.add(gradingInfoTextArea, BorderLayout.CENTER);

        gradingFrame.setVisible(true);
    }

    private static void showAboutUsWindow() {
        JFrame aboutFrame = new JFrame("About Us");
        aboutFrame.setSize(800, 400);
        aboutFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        aboutFrame.setLayout(new BorderLayout());

        // Set the background color for the aboutFrame
        aboutFrame.getContentPane().setBackground(Color.decode("#101238"));

        // Introduction label
        JLabel introLabel = new JLabel("<html><h2 style='color: white;'>About the University Grade Encoding System</h2>"
                + "<p style='color: white;'>This system allows users to encode grades for students efficiently. "
                + "Follow the tutorial below to understand how to use the system.</p></html>", SwingConstants.CENTER);
        introLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        aboutFrame.add(introLabel, BorderLayout.NORTH);

        // Tutorial text area
        JTextArea tutorialTextArea = new JTextArea();
        tutorialTextArea.setText("\nEncode Grades: You can input student info along with their grades then press the encode grade button to add it to the table.\n"
                + "\nGrading System: It shows the grading system of our university, displaying the required grades to pass a subject.\n"
                + "\nAbout Us: Learn a little introduction about our system and what it provides.\n"
                + "\nLogout: Use the logout button to exit the system safely.");
        
        tutorialTextArea.setFont(new Font("Arial", Font.PLAIN, 14));
        tutorialTextArea.setEditable(false);
        tutorialTextArea.setBackground(Color.decode("#101238"));
        tutorialTextArea.setForeground(Color.WHITE); // Set the font color to white
        aboutFrame.add(tutorialTextArea, BorderLayout.CENTER);

        aboutFrame.setVisible(true);
    }

    private static void showLoginWindow() {
        main(null);
    }
}